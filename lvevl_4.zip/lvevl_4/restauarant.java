package Redrock.the1time.lvevl_4;

import java.util.Scanner;

public class restauarant {
    public void pay(){
        Scanner sc = new Scanner(System.in);
        String[] paychoice= {"支付宝","微信","人脸识别"};
        int[] number = {1,2,3};
        System.out.println("请选择支付方式");
        for (int i = 0; i < 3; i++) {
            System.out.println(number[i] + "." + paychoice[i]);
        }
       sc.nextInt(4);
        System.out.println("请出示付款码....");
    }//支付的方法,拿下

    public void sayHello(){
        System.out.println("欢迎来到国民饭店,这是今天的菜单:");
    }//欢迎的方法,拿下

}
