package Redrock.the1time.lvevl_4;

public class demo01main {
    public static void main(String[] args) {
        menu menu = new menu();
        restauarant restauarant =  new restauarant();
        choice_dishes choice_dishes = new choice_dishes();//分别创建对象

        restauarant.sayHello();//第一步,打招呼
        choice_dishes.show_dishes();//展示菜单
        choice_dishes.choice_dishes_main_body();//两次点菜程序
        choice_dishes.choice_dishes_main_body();
        restauarant.pay();//最后一步,付款
    }
}
