package Redrock.the1time.lvevl_4;

public class menu {
   String[] dishes  = {"辣子鸡丁","水煮肉片","糖醋里脊","干锅牛肉","干锅排骨"};
   int[] price = {38,22,18,38,29};
   int[] number = {1,2,3,4,5};
}//拿下,是否可以私有化,有时间继续
