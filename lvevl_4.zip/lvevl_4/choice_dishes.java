package Redrock.the1time.lvevl_4;

import java.util.Scanner;

public class choice_dishes extends menu{
    Scanner sc = new Scanner(System.in);
    int i = 0,sum = 0;
    public void show_dishes(){
        for (int i = 0; i < 5; i++) {
            System.out.println(number[i] + "." + dishes[i] + " " + price[i] + "元");
        }
    }//显示菜单的方法,拿下

    public void choice_dishes_main_body(){
        if(i == 0) {
            System.out.println("请输入想要点的菜的序号(空格键分割)");
            String input = sc.nextLine();
            String[] temp = input.split(" ");//截成字符串：123
            int n = 0;
            for(String date:temp) {
                n++;
            }
            int[] temp1 = new int[n];
            for (int j = 0; j < n; j++) {
                temp1[j] = Integer.parseInt(temp[j]);
            }//到这里为止，我有了一个名为temp1的数组，其中是{1，2，3}这样
            show_price(temp1);
        }else{
            System.out.println("还有需要点的菜么?");
            show_dishes();
            System.out.println("请输入想要点的菜的序号(空格键分割)");
            String input = sc.nextLine();
            String[] temp = input.split(" ");//截成字符串：123
            int n = 0;
            for(String date:temp) {
                n++;
            }
            int[] temp1 = new int[n];
            for (int j = 0; j < n; j++) {
                temp1[j] = Integer.parseInt(temp[j]);
            }
            show_price(temp1);
        }
        i++;
        System.out.println("共计" + sum + "元");
    }//点菜的方法

    public int show_price(int temp[]){
        System.out.println("你一共选择了:");
        for (int i = 0; i < temp.length; i++) {
            switch (temp[i]){
                case 1:
                    System.out.println(dishes[0] + " " + price[0] + "元");
                    sum += price[0];
                    break;
                case 2:
                    System.out.println(dishes[1] + " " + price[1] + "元");
                    sum += price[1];
                    break;
                case 3:
                    System.out.println(dishes[2] + " " + price[2] + "元");
                    sum += price[2];
                    break;
                case 4:
                    System.out.println(dishes[3] + " " + price[3] + "元");
                    sum += price[3];
                    break;
                case 5:
                    System.out.println(dishes[4] + " " + price[4] + "元");
                    sum += price[4];
                    break;
            }
        }
        return sum;
    }//返回价格的方法:未完成

}
